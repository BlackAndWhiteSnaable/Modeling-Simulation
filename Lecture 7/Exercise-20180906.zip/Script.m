% load data and (tf model 'idtf')
load('Dryer.mat')
load('Dryerd.mat')
load('tf1.mat')

% extract numerator and denumarator coefficients form the 'idtf'
num = tf1.Numerator
den = tf1.Denominator

% Make Time vector
Ts=Dryer.Ts;
Time = 0:Ts:(Ts*1000)-Ts;

% Prepare data for simulink
var1.time=[Time]
var1.signals.values=[Dryerd.InputData]
var2.time=[Time]
var2.signals.values=[Dryerd.OutputData]
 
 
