%% Create a transfer function and plot using a step function
s=tf('s')
m=1;
L=5;
L1=10;
g=9.81;
sys=(1/(m*L^2))/(s^2+g/L);
sys1=(1/(m*L^2))/(s^2+g/L1);
time = 100;
t=0:0.1:time;
y=step(sys,t);
y1=step(sys1,t);
%% Different plotting functionalities
figure(1)
subplot(2,2,1)
plot(t,y*57.3,'k--') %fgfdgdfg 
hold on
plot(t,y1*57.3,'k-o')
legend('angle [\Theta]','angle 2 [\Theta]')
title('Angle')
ylabel('Angle [\circ]')
xlabel('Time [s]')
% axis([0 10 0 0.01])
grid minor
hold off
subplot(2,2,2)
pzmap(sys)
subplot(2,2,3)
bode(sys)
subplot(2,2,4)
plotyy(t,y,t,y*57.3)
%% Simulate the transfer function in simulink and plot in matlab
figure(2)
[numer,dennum] = tfdata(sys);
num = cell2mat(numer);
den = cell2mat(dennum);
sim test.slx
plot(simout.Data)

%% Simulate the trasnfer function using lsim
time = 100;
ts=0.1;
t=0:ts:time;
u=ones(1,size(t,2));
lsim(sys,u,t);
axis([0 100 0 0.05])

